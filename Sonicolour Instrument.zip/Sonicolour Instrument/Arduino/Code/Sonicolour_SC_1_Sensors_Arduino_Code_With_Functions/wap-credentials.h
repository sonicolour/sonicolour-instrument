//wap-credentials.h header file
#define SECRET_SSID "SC-1 #0001"
#define SECRET_PASSWORD "password0001"